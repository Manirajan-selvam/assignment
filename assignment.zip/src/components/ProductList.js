import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import axios from "axios";
import {
  Rating,
  IconButton,
  Typography,
  TablePagination,
  Card,
  CardMedia,
  CardActions,
  CardContent,
} from "@mui/material";
import actionTypes from "./../actions/types";
import "./../resources/product.css";
import { deepClone } from "fast-json-patch";
import ModifyProduct from "./ModifyProduct";
import CreateSharpIcon from "@mui/icons-material/CreateSharp";
function ProductList() {
  const dispatch = useDispatch();
  const productlistData = deepClone(
    useSelector((state) => state?.productreducer)
  );
  const [page, setPage] = useState(1);
  const [value, setValue] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  useEffect(() => {
    axios
      .get(
        `https://dummyjson.com/products?limit=${rowsPerPage}&skip=${
          (page - 1) * rowsPerPage
        }`
      )
      .then((result) => {
        dispatch({
          type: actionTypes.PROD_LIST.UPDATE,
          payload: [
            {
              key: "productlist",
              value: result?.data?.products,
            },
            {
              key: "productlistcount",
              value: result?.data?.total,
            },
          ],
        });
      })
      .catch((fault) => {
        window.alert("Error while fetching product info" + fault.message);
      });
  }, [page, rowsPerPage]);

  const handleEdit = (e, index) => {
    dispatch({
      type: actionTypes.PROD_MODIFICATION.EDIT,
      payload: [
        {
          key: "dialogopened",
          value: true,
        },
        {
          key: "productindex",
          value: index,
        },
        {
          key: "productitem",
          value: productlistData?.productlist[index],
        },
      ],
    });
  };

  const handlePageChange = (event, value) => {
    setPage(value);
  };

  const handleRowsPerPageChange = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(1);
  };

  return (
    <div className="productlist display-column">
      <h4 className="product-header">Product List</h4>
      <div className="productlistcards">
        {productlistData?.productlist?.map((item, index) => {
          return (
            <Card
              key={index}
              sx={{
                minWidth: 220,
                maxWidth: 220,
                border: "2px solid",
                borderColor:
                  item?.availabilityStatus === "Low Stock" ? "red" : "green",
              }}
            >
              <CardActions>
                <IconButton
                  onClick={(e) => {
                    handleEdit(e, index);
                  }}
                >
                  <CreateSharpIcon />
                </IconButton>
              </CardActions>
              <CardMedia sx={{ height: 140 }} image={item?.thumbnail} />
              <CardContent className="productlistcardcontent">
                <Typography className="productcardtitle">
                  {item?.title}
                </Typography>
                <div className="display-row item-gap">
                  <div className="display-column">
                    <Typography className="productclassifytitle">
                      Category
                    </Typography>
                    <Typography className="productclassifyvalue">
                      {item?.category?.slice(0, 1)?.toUpperCase() +
                        item?.category?.slice(1)}
                    </Typography>
                  </div>
                  <div className="display-column">
                    <Typography className="productclassifytitle">
                      Rating
                    </Typography>

                    <Rating
                      name="size-small"
                      size="small"
                      value={item?.rating || value}
                      disabled={true}
                      precision={0.5}
                      onChange={(event, newValue) => {
                        setValue(newValue);
                      }}
                    />
                  </div>
                  <div className="display-column">
                    <Typography className="productclassifytitle">
                      Price
                    </Typography>
                    <Typography className="productclassifyvalue">
                      {item?.price}
                    </Typography>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
      <TablePagination
        component="div"
        count={productlistData?.productlistcount || 0}
        page={page}
        onPageChange={handlePageChange}
        rowsPerPage={rowsPerPage}
        onRowsPerPageChange={handleRowsPerPageChange}
        rowsPerPageOptions={[5, 10, 15]}
      />

      <ModifyProduct />
    </div>
  );
}

export default ProductList;
