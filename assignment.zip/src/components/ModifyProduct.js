import React, { useState, useEffect, useRef } from "react";
import { deepClone } from "fast-json-patch";
import { useSelector, useDispatch } from "react-redux";
import actionTypes from "./../actions/types";
import CloseIcon from "@mui/icons-material/Close";
import { Dialog, DialogTitle, Button } from "@mui/material";
import "./../resources/product.css";
function ModifyProduct(props) {
  const dispatch = useDispatch();
  const productModified = deepClone(useSelector((state) => state?.editproduct));
  const [productTitle, setProductTitle] = useState("");
  const [productCategory, setProductCategory] = useState("");
  const [productRating, setProductRating] = useState("");
  const [productPrice, setProductPrice] = useState("");
  const [productThumbnail, setProductThumbnail] = useState("");
  const initialRender = useRef(true);
  useEffect(() => {
    if (productModified?.productitem && initialRender.current) {
      setProductTitle(productModified.productitem.title || "");
      setProductCategory(productModified.productitem.category || "");
      setProductRating(productModified.productitem.rating || "");
      setProductPrice(productModified.productitem.price || "");
      setProductThumbnail(productModified.productitem.thumbnail || "");
      initialRender.current = false;
    }
  }, [productModified?.productitem]);

  const handleClose = (value) => {
    dispatch({
      type: actionTypes.PROD_MODIFICATION.EDIT,
      payload: [
        {
          key: "dialogopened",
          value: false,
        },
      ],
    });
  };
  const handleSubmit = () => {
    let productobj = productModified?.productitem;
    if (productTitle != "") {
      productobj.title = productTitle;
    }
    if (productCategory != "") {
      productobj.category = productCategory;
    }
    if (productRating != "") {
      productobj.rating = productRating;
    }
    if (productPrice != "") {
      productobj.price = productPrice;
    }
    if (productThumbnail != "") {
      productobj.thumbnail = productThumbnail;
    }
    dispatch({
      type: actionTypes.PROD_LIST.MODIFY,
      payload: {
        productmodifeditem: productobj,
        index: productModified?.productindex,
      },
    });
    dispatch({
      type: actionTypes.PROD_MODIFICATION.EDIT,
      payload: [
        {
          key: "dialogopened",
          value: false,
        },
      ],
    });
  };
  return (
    <Dialog onClose={handleClose} open={productModified?.dialogopened}>
      <DialogTitle className="modify-dialog-content">
        <div className="display-row">
          <label className="modify-dialog-label">Edit Product</label>
          <CloseIcon onClick={handleClose} />
        </div>
      </DialogTitle>
      <form className="display-column item-gap item-padding">
        <label className="display-column productclassifytitle popup-item-size">
          Title:
          <input
            type="text"
            className="productclassifyvalue"
            value={productTitle}
            onChange={(e) => setProductTitle(e.target.value)}
          />
        </label>
        <label className="display-column productclassifytitle popup-item-size">
          Category:
          <input
            type="text"
            className="productclassifyvalue"
            value={
              productCategory?.slice(0, 1)?.toUpperCase() +
              productCategory?.slice(1)
            }
            onChange={(e) => setProductCategory(e.target.value)}
          />
        </label>
        <label className="display-column productclassifytitle popup-item-size">
          Rating:
          <input
            type="text"
            className="productclassifyvalue"
            value={productRating}
            onChange={(e) => setProductRating(e.target.value)}
          />
        </label>
        <label className="display-column productclassifytitle popup-item-size">
          Price:
          <input
            type="text"
            className="productclassifyvalue"
            value={productPrice}
            onChange={(e) => setProductPrice(e.target.value)}
          />
        </label>
        <label className="display-column productclassifytitle popup-item-size">
          Thumbnail:
          <input
            type="text"
            className="productclassifyvalue"
            value={productThumbnail}
            onChange={(e) => setProductThumbnail(e.target.value)}
          />
        </label>
        <Button
          onClick={(e) => {
            handleSubmit(e);
          }}
        >
          Submit
        </Button>
      </form>
    </Dialog>
  );
}
export default ModifyProduct;
