const PROD_LIST = {
    UPDATE: "UPDATING_PROD_LIST",
    MODIFY: "MODIFYING_PROD_LIST",
};
const PROD_MODIFICATION = {
    EDIT: "EDITING_PROD_ITEM",
};
const types = {
    PROD_LIST,
    PROD_MODIFICATION,
};
export default types;