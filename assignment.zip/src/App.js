import React from "react";
import "./resources/App.css";
import { BrowserRouter, Route, NavLink, Routes } from "react-router-dom";
import ProductList from "./components/ProductList";
import About from "./components/About";

function App() {
  return (
    <div className="App display-row">
      <BrowserRouter>
        <div className="leftgroup display-column">
          <h2 style={{ textAlign: "center", color: "darkblue" }}>Maze kart</h2>
          <nav className="display-column" style={{ alignItems: "center" }}>
            <NavLink
              to="/about"
              className={({ isActive }) =>
                isActive ? "activelink" : "inactivelink"
              }
            >
              About
            </NavLink>
            <NavLink
              to="/product"
              className={({ isActive }) =>
                isActive ? "activelink" : "inactivelink"
              }
            >
              Product List
            </NavLink>
          </nav>
        </div>
        <div className="rightgroup display-column">
          <Routes>
            <Route exact path="/" element={<ProductList />} />
            <Route path="/about" element={<About />} />
            <Route path="/product" element={<ProductList />} />
          </Routes>
        </div>
      </BrowserRouter>
    </div>
  );
}

export default App;
