import { combineReducers } from "redux";
import productreducer from "./productreducer";
import editproduct from "./editproduct";
const combinedReducers = {
    productreducer,
    editproduct,
};
const rootReducer = combineReducers({
    ...combinedReducers,
});
export default rootReducer;