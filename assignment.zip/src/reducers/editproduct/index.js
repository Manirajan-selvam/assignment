import produce from "immer";
import actionTypes from "../../actions/types";
const reducer = (state = {}, action) => {
  const { type, payload } = action;
  return produce(state, (draft) => {
    switch (type) {
      case actionTypes.PROD_MODIFICATION.EDIT:
        Object.keys(payload).map((key) => {
          draft[payload[key]?.key] = payload[key]?.value;
        });
        break;
      default:
    }
  });
};

export default reducer;
