import produce from "immer";
import actionTypes from "../../actions/types";
import { deepClone } from "fast-json-patch";
const Update_Product_list = (draft, state, payload) => {
  if (payload?.productmodifeditem) {
    let list = deepClone(state.productlist);
    let filterList = list.filter(
      (i) => i?.id !== payload?.productmodifeditem?.id
    );
    filterList.splice(payload?.index, 0, payload?.productmodifeditem);
    draft.productlist = filterList;
  }
};
const reducer = (state = {}, action) => {
  const { type, payload } = action;
  return produce(state, (draft) => {
    switch (type) {
      case actionTypes.PROD_LIST.UPDATE:
        Object.keys(payload).map((key) => {
          draft[payload[key]?.key] = payload[key]?.value;
        });
        break;
      case actionTypes.PROD_LIST.MODIFY:
        Update_Product_list(draft, state, payload);
        break;
      default:
    }
  });
};

export default reducer;
